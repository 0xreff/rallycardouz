import * as THREE from "three";
import { Physics } from "../physics/Physics";
import { Car } from "./Car";
import { avoidanceControl } from "./handling";
import type { ControlState } from "../engine/Input";

const UP = new THREE.Vector3(0, 1, 0);

/**
 * A simple AI driver: cruises the arena, wanders with a slowly drifting random
 * steer, and avoids crashing by casting three rays ahead (left / centre / right)
 * and steering toward the most open side, easing off the throttle when something
 * is close. If it gets pinned, it backs up and turns to free itself.
 *
 * It produces a ControlState each step, exactly like keyboard Input, so the bot
 * drives a normal Car with no special-casing in the physics. The returned object
 * is reused (the caller consumes it immediately), and all vectors are scratch
 * fields, so sampling allocates nothing per frame.
 */
export class BotController {
  private wander = 0;       // smoothed wander steer
  private wanderTarget = 0; // current random steer goal
  private wanderTimer = 0;  // time until the goal is re-rolled
  private stuckTime = 0;    // how long we've been barely moving
  private reverseTimer = 0; // >0 while backing out of being stuck
  private reverseDir = 1;
  private _rayDir = new THREE.Vector3();
  private _ray: any = null; // RAPIER.Ray
  private _pos = new THREE.Vector3();
  private _fwd = new THREE.Vector3();
  private _vel = new THREE.Vector3();
  private _origin = new THREE.Vector3();
  private _left = new THREE.Vector3();
  private _right = new THREE.Vector3();
  private out: ControlState = {
    throttle: 0,
    brake: 0,
    steer: 0,
    handbrake: false,
    unlockSixth: true, // bots take 6th on their own when they reach the limiter
    reset: false,
    recover: false,
    cycleCar: false,
    changeView: false,
    lookLeft: false,
    lookRight: false,
    lookBack: false,
  };

  constructor(private physics: Physics, private car: Car) { }

  sample(dt: number): ControlState {
    const out = this.out;
    out.throttle = 0;
    out.brake = 0;
    out.steer = 0;

    const pos = this.car.position(this._pos);
    const fwd = this.car.forwardVector(this._fwd);
    const vel = this.car.velocity(this._vel);
    const speed = vel.dot(fwd);

    // --- Stuck recovery: pinned for a while → back up and turn out. ---
    if (this.reverseTimer > 0) {
      this.reverseTimer -= dt;
      out.brake = 1;
      out.steer = this.reverseDir;
      return out;
    }
    if (Math.abs(speed) < 0.6) {
      this.stuckTime += dt;
      if (this.stuckTime > 1.2) {
        this.reverseTimer = 0.9;
        this.reverseDir = Math.random() < 0.5 ? -1 : 1;
        this.stuckTime = 0;
      }
    } else {
      this.stuckTime = 0;
    }

    // --- Wander: a lazily drifting random steer goal. ---
    this.wanderTimer -= dt;
    if (this.wanderTimer <= 0) {
      this.wanderTarget = (Math.random() * 2 - 1) * 0.5;
      this.wanderTimer = 1.5 + Math.random() * 2;
    }
    this.wander += (this.wanderTarget - this.wander) * Math.min(1, 2 * dt);

    // --- Obstacle avoidance: three rays ahead, look further the faster we go. ---
    const look = THREE.MathUtils.clamp(Math.abs(speed) * 0.6 + 6, 6, 18);
    const origin = this._origin.copy(pos).addScaledVector(fwd, 1.2); // just ahead of the nose
    const right = this._right.copy(fwd).applyAxisAngle(UP, 0.45); // +angle = car's right side
    const left = this._left.copy(fwd).applyAxisAngle(UP, -0.45);
    const dC = this.cast(origin, fwd, look);
    const dR = this.cast(origin, right, look);
    const dL = this.cast(origin, left, look);

    const c = avoidanceControl(dC, dL, dR, look, this.wander);
    out.throttle = c.throttle;
    out.steer = c.steer;
    return out;
  }

  /** Distance to the nearest obstacle along dir (normalised), or look if clear. */
  /** Distance to the nearest obstacle along dir (normalised), or look if clear. */
  private cast(origin: THREE.Vector3, dir: THREE.Vector3, look: number): number {
    this._rayDir.copy(dir).normalize();
    if (!this._ray) {
      this._ray = new this.physics.rapier.Ray(
        { x: origin.x, y: origin.y, z: origin.z },
        { x: this._rayDir.x, y: this._rayDir.y, z: this._rayDir.z }
      );
    } else {
      this._ray.origin.x = origin.x;
      this._ray.origin.y = origin.y;
      this._ray.origin.z = origin.z;
      this._ray.dir.x = this._rayDir.x;
      this._ray.dir.y = this._rayDir.y;
      this._ray.dir.z = this._rayDir.z;
    }
    const hit = this.physics.world.castRay(this._ray, look, true, undefined, undefined, undefined, this.car.body);
    return hit ? hit.timeOfImpact : look;
  }
}