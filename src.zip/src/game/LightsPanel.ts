import {
    getLightSettings,
    getPlayerRig,
    getRigDefaults,
    RIGS,
    setBrakePreview,
    setLightSettings,
    type LightSettings,
    type RigId,
} from "./CarLights";

/**
 * In-game light editor. Press L (or click the 💡 button, top right) to open it.
 *
 *  - CAR selector (top): every car has its own light design and its own saved settings
 *    (Toyota, Toyota6, Other cars). It opens on the car you are driving.
 *  - Sections fold: click a title. Move the sliders / pick colours.
 *  - SAVE applies the settings to that car's lights AND stores them in the browser.
 *  - "Live preview" applies every change instantly (without saving) while the panel is open;
 *    closing the panel without saving puts the saved look back.
 *  - "Show brake lights" holds the red lamps in their braking look so you can tune them.
 *  - Defaults loads the original look of the selected car into the panel (press Save to apply).
 *
 * The panel swallows the keyboard while it has focus, so typing / arrow keys in it never steer.
 */

type NumKey = { [K in keyof LightSettings]: LightSettings[K] extends number ? K : never }[keyof LightSettings];
type BoolKey = { [K in keyof LightSettings]: LightSettings[K] extends boolean ? K : never }[keyof LightSettings];
type StrKey = { [K in keyof LightSettings]: LightSettings[K] extends string ? K : never }[keyof LightSettings];

type Field =
    | { kind: "toggle"; key: BoolKey; label: string }
    | { kind: "color"; key: StrKey; label: string }
    | { kind: "slider"; key: NumKey; label: string; min: number; max: number; step: number };

interface Section { title: string; open?: boolean; fields: Field[] }

const T = (key: BoolKey, label: string): Field => ({ kind: "toggle", key, label });
const C = (key: StrKey, label: string): Field => ({ kind: "color", key, label });
const S = (key: NumKey, label: string, min: number, max: number, step: number): Field => ({ kind: "slider", key, label, min, max, step });

const POS_X = (key: NumKey) => S(key, "Position X (width / spread)", 0, 1.3, 0.01);
const POS_Y = (key: NumKey) => S(key, "Position Y (height)", -1.2, 3, 0.01);
const POS_Z = (key: NumKey) => S(key, "Position Z (front / back)", -1.3, 1.3, 0.01);

const SECTIONS: Section[] = [
    {
        title: "Headlights (main pair)", open: true,
        fields: [
            T("headOn", "Headlights on"), C("headColor", "Light colour"),
            T("headRound", "Round lamps (off = rectangle)"),
            S("headSize", "Lamp size (m)", 0.08, 0.5, 0.01),
            POS_X("headX"), POS_Y("headY"), POS_Z("headZ"),
            S("headTilt", "Vertical tilt (0 = level)", -0.05, 0.15, 0.005),
            S("headYaw", "Horizontal spread / yaw", -0.05, 0.2, 0.005),
            S("spotIntensity", "Road light brightness", 0, 1000, 10),
            S("spotAngle", "Road light width", 0.15, 0.9, 0.01),
            S("spotPenumbra", "Edge softness", 0, 1, 0.01),
            S("spotSpread", "Space between the 2 pools", 0, 5, 0.1),
            S("spotWidthComp", "Road light: same light when widened", 0, 1, 0.05),
            S("spotDecay", "Road light falloff (lower = flatter)", 0.2, 1.5, 0.05),
            S("headCore", "Lamp brightness", 0, 10, 0.1),
            S("beamStrength", "Light shaft strength", 0, 0.6, 0.01),
            S("beamWidth", "Light shaft width", 0.3, 2.5, 0.05),
            S("beamLength", "Light shaft length", 6, 30, 1),
            S("beamWidthComp", "Shaft: same brightness when widened", 0, 2, 0.05),
            S("beamNearFade", "Shaft: fade-in from lamp (m)", 0, 5, 0.1),
            S("beamCamFade", "Shaft: fade out near camera (m)", 2, 15, 0.5),
        ],
    },
    {
        title: "Upper round lamps (Toyota)",
        fields: [T("topOn", "Upper round lamps on"), S("topSize", "Lamp size (m)", 0.08, 0.5, 0.01),
        POS_X("topX"), POS_Y("topY"), POS_Z("topZ")],
    },
    {
        title: "Roof LED bar (Toyota6)",
        fields: [T("barOn", "Roof bar on"), S("barW", "Length (m)", 0.3, 2.2, 0.05), S("barH", "Thickness (m)", 0.02, 0.3, 0.01),
        POS_Y("barY"), POS_Z("barZ"),
        S("barGlow", "Brightness", 0, 12, 0.1), S("barHalo", "Soft glow size", 0, 2, 0.05),
        S("barBeam", "Fan light shaft strength", 0, 0.5, 0.01), S("barBeamLen", "Fan light length (m)", 6, 40, 1),
        S("barLight", "Light on the road (0 = off)", 0, 400, 5)],
    },
    {
        title: "Amber lamps - front",
        fields: [T("amberOn", "Amber lamps on"), C("amberColor", "Amber colour"),
        T("amberRect", "Vertical rectangles (off = round)"),
        POS_X("amberX"), POS_Y("amberY"), POS_Z("amberZ"),
        S("amberW", "Width (m)", 0.03, 0.5, 0.01), S("amberH", "Height (m)", 0.03, 0.5, 0.01),
        S("amberGlow", "Glow", 0, 8, 0.1),
        S("amberWash", "Amber on ground + car (0 = off)", 0, 10, 0.1), S("amberReach", "Amber light reach (m)", 1, 10, 0.5)],
    },
    {
        title: "Amber lamps - rear",
        fields: [T("amberTailOn", "Rear amber lamps on"), POS_X("amberTailX"), POS_Y("amberTailY"), POS_Z("amberTailZ"),
        S("amberTailW", "Width (m)", 0.03, 0.5, 0.01), S("amberTailH", "Height (m)", 0.03, 0.5, 0.01)],
    },
    {
        title: "Tail lights (red)", open: true,
        fields: [T("tailOn", "Tail lights on"), C("tailColor", "Colour"),
        T("tailRect", "Rectangles (off = round)"),
        S("tailW", "Lamp width (m)", 0.03, 0.6, 0.01), S("tailH", "Lamp height (m)", 0.03, 0.6, 0.01),
        POS_X("tailX"), POS_Y("tailY"), POS_Z("tailZ"),
        T("tail2On", "Second row of lamps"), POS_Y("tail2Y"),
        T("tailMidOn", "Middle bar"), POS_Y("tailMidY"),
        S("tailMidW", "Middle bar width (m)", 0.1, 1.5, 0.01), S("tailMidH", "Middle bar height (m)", 0.02, 0.3, 0.01),
        S("tailGlowIdle", "Glow (lights on)", 0, 8, 0.1), S("tailGlowBrake", "Glow (braking)", 0, 20, 0.5),
        S("ledBar", "LED bar brightness", 0, 3, 0.1),
        S("haloSizeIdle", "Halo size (lights on)", 0, 1.5, 0.05), S("haloSizeBrake", "Halo size (braking)", 0, 3, 0.05),
        S("haloStrength", "Halo strength", 0, 3, 0.1)],
    },
    {
        title: "Red light on ground + car",
        fields: [S("groundRedIdle", "Red on ground (lights on)", 0, 10, 0.1), S("groundRedBrake", "Red on ground (braking)", 0, 20, 0.5),
        S("tailReach", "Ground reach (m)", 1, 20, 0.5), S("tailAim", "Aim behind the car (m)", 0.5, 8, 0.1),
        S("tailAngle", "Width", 0.2, 1.4, 0.05), S("tailOffset", "Distance behind the lamps (m)", 0, 1, 0.05),
        S("tailBodyIdle", "Red on the car (lights on)", 0, 10, 0.1), S("tailBodyBrake", "Red on the car (braking)", 0, 20, 0.1),
        S("tailBodyReach", "Car wash reach (m)", 0.5, 4, 0.1)],
    },
    {
        title: "Glare control",
        fields: [S("lampFadeDist", "Dim lamps closer than (m)", 3, 25, 0.5), S("lampNearMin", "Brightness when very close", 0, 1, 0.05)],
    },
];

const CSS = `
#lightsBtn, #lightsPanel { font-family: "Segoe UI", system-ui, sans-serif; color: #eaf2ff; }
#lightsBtn {
  position: fixed; right: 24px; top: 20px; z-index: 30; cursor: pointer;
  padding: 7px 12px; font-size: 13px; font-weight: 600; letter-spacing: .3px;
  background: rgba(14,18,36,.72); border: 1px solid rgba(160,180,255,.28); border-radius: 10px;
  backdrop-filter: blur(6px);
}
#lightsBtn:hover { background: rgba(30,38,72,.85); }
#lightsPanel {
  position: fixed; right: 24px; top: 64px; z-index: 30; width: 320px;
  max-height: calc(100vh - 90px); display: none; flex-direction: column;
  background: rgba(10,13,28,.88); border: 1px solid rgba(160,180,255,.25); border-radius: 14px;
  backdrop-filter: blur(10px); box-shadow: 0 10px 40px rgba(0,0,0,.5); font-size: 13px;
}
#lightsPanel.open { display: flex; }
#lightsPanel .lp-head { padding: 12px 14px 6px; font-size: 15px; font-weight: 700; display: flex; justify-content: space-between; align-items: center; }
#lightsPanel .lp-head button { background: none; border: 0; color: inherit; font-size: 18px; cursor: pointer; opacity: .7; }
#lightsPanel .lp-car { display: flex; align-items: center; gap: 8px; padding: 0 14px 8px; }
#lightsPanel .lp-car select { flex: 1; padding: 6px 8px; font-size: 13px; font-weight: 600; color: inherit; background: rgba(255,255,255,.08); border: 1px solid rgba(160,180,255,.3); border-radius: 8px; }
#lightsPanel .lp-car select option { background: #15182c; }
#lightsPanel .lp-body { overflow-y: auto; padding: 0 14px 6px; flex: 1; }
#lightsPanel h4 { margin: 12px 0 6px; font-size: 11px; letter-spacing: 1.6px; text-transform: uppercase; color: #9fb4ff; cursor: pointer; user-select: none; }
#lightsPanel h4::before { content: "\\25BE  "; }
#lightsPanel h4.closed::before { content: "\\25B8  "; }
#lightsPanel .sec.closed { display: none; }
#lightsPanel .row { display: grid; grid-template-columns: 1fr auto; align-items: center; gap: 2px 8px; margin: 7px 0; }
#lightsPanel .row .val { font-variant-numeric: tabular-nums; opacity: .7; font-size: 12px; }
#lightsPanel .row input[type=range] { grid-column: 1 / 3; width: 100%; accent-color: #7f98ff; }
#lightsPanel .row input[type=color] { width: 44px; height: 24px; border: 0; padding: 0; background: none; cursor: pointer; }
#lightsPanel .row input[type=checkbox] { width: 18px; height: 18px; accent-color: #7f98ff; }
#lightsPanel .opts { padding: 8px 14px 0; border-top: 1px solid rgba(160,180,255,.15); }
#lightsPanel .opts label { display: flex; align-items: center; gap: 8px; margin: 4px 0; cursor: pointer; }
#lightsPanel .foot { display: flex; gap: 8px; padding: 10px 14px 12px; align-items: center; }
#lightsPanel .foot button {
  flex: 1; padding: 9px 0; font-size: 13px; font-weight: 700; cursor: pointer; border-radius: 9px;
  border: 1px solid rgba(160,180,255,.3); background: rgba(255,255,255,.07); color: inherit;
}
#lightsPanel .foot button.save { background: linear-gradient(180deg,#6f8fff,#4f6be0); border-color: transparent; }
#lightsPanel .foot button:hover { filter: brightness(1.15); }
#lightsPanel .status { padding: 0 14px 10px; min-height: 16px; font-size: 12px; color: #8fe3a8; }
#lightsPanel .status.dirty { color: #ffd34d; }
`;

export class LightsPanel {
    private readonly panel: HTMLDivElement;
    private readonly btn: HTMLButtonElement;
    private readonly status: HTMLDivElement;
    private readonly live: HTMLInputElement;
    private readonly brake: HTMLInputElement;
    private readonly carSel: HTMLSelectElement;
    private readonly syncers: Array<() => void> = [];
    private rig: RigId = getPlayerRig();
    private draft: LightSettings;
    private saved: LightSettings;
    private open = false;

    constructor() {
        this.saved = getLightSettings(this.rig);
        this.draft = { ...this.saved };

        const style = document.createElement("style");
        style.textContent = CSS;
        document.head.appendChild(style);

        this.btn = document.createElement("button");
        this.btn.id = "lightsBtn";
        this.btn.textContent = "💡 Lights (L)";
        this.btn.addEventListener("click", () => this.toggle());
        document.body.appendChild(this.btn);

        this.panel = document.createElement("div");
        this.panel.id = "lightsPanel";
        document.body.appendChild(this.panel);

        const head = document.createElement("div");
        head.className = "lp-head";
        head.innerHTML = "<span>Vehicle lights</span>";
        const close = document.createElement("button");
        close.textContent = "✕";
        close.title = "Close";
        close.addEventListener("click", () => this.setOpen(false));
        head.appendChild(close);
        this.panel.appendChild(head);

        // car selector: every car has its own light design and its own saved settings
        const car = document.createElement("div");
        car.className = "lp-car";
        car.append(document.createTextNode("Car"));
        this.carSel = document.createElement("select");
        for (const r of RIGS) {
            const o = document.createElement("option");
            o.value = r.id;
            o.textContent = r.label;
            this.carSel.appendChild(o);
        }
        this.carSel.value = this.rig;
        this.carSel.addEventListener("change", () => this.switchRig(this.carSel.value as RigId));
        car.appendChild(this.carSel);
        this.panel.appendChild(car);

        // controls (sections fold when you click their title)
        const body = document.createElement("div");
        body.className = "lp-body";
        for (const sec of SECTIONS) {
            const h = document.createElement("h4");
            h.textContent = sec.title;
            const wrap = document.createElement("div");
            wrap.className = "sec";
            const fold = (closed: boolean) => { h.classList.toggle("closed", closed); wrap.classList.toggle("closed", closed); };
            fold(!sec.open);
            h.addEventListener("click", () => fold(!h.classList.contains("closed")));
            body.appendChild(h);
            for (const f of sec.fields) wrap.appendChild(this.buildRow(f));
            body.appendChild(wrap);
        }
        this.panel.appendChild(body);

        const opts = document.createElement("div");
        opts.className = "opts";
        this.live = this.buildCheck(opts, "Live preview (apply while editing)");
        this.brake = this.buildCheck(opts, "Show brake lights");
        this.live.addEventListener("change", () => {
            setLightSettings(this.live.checked ? this.draft : this.saved, false, this.rig);
            this.updateStatus();
        });
        this.brake.addEventListener("change", () => setBrakePreview(this.brake.checked));
        this.panel.appendChild(opts);

        const foot = document.createElement("div");
        foot.className = "foot";
        const save = document.createElement("button");
        save.className = "save";
        save.textContent = "Save";
        save.title = "Apply to this car's lights and remember it";
        save.addEventListener("click", () => this.save());
        const defaults = document.createElement("button");
        defaults.textContent = "Defaults";
        defaults.title = "Load this car's original look (press Save to apply)";
        defaults.addEventListener("click", () => {
            this.draft = getRigDefaults(this.rig);
            this.syncUI();
            if (this.live.checked) setLightSettings(this.draft, false, this.rig);
            this.updateStatus();
        });
        foot.append(save, defaults);
        this.panel.appendChild(foot);

        this.status = document.createElement("div");
        this.status.className = "status";
        this.panel.appendChild(this.status);

        // Keep the keyboard inside the panel and release any key the game thinks is held.
        this.panel.addEventListener("keydown", (e) => {
            e.stopPropagation();
            if (e.key === "Escape") this.setOpen(false);
        });
        this.panel.addEventListener("keyup", (e) => e.stopPropagation());
        this.panel.addEventListener("focusin", () => window.dispatchEvent(new Event("blur")));
        window.addEventListener("keydown", (e) => {
            if (e.code === "KeyL" && !e.repeat && !e.ctrlKey && !e.metaKey && !e.altKey) this.toggle();
        });

        this.syncUI();
    }

    toggle(): void { this.setOpen(!this.open); }

    private setOpen(on: boolean): void {
        if (on === this.open) return;
        this.open = on;
        this.panel.classList.toggle("open", on);
        if (on) {
            this.rig = getPlayerRig();           // open on the car you are driving
            this.carSel.value = this.rig;
            this.saved = getLightSettings(this.rig);
            this.draft = { ...this.saved };
            this.syncUI();
            this.updateStatus();
        } else {
            setLightSettings(this.saved, false, this.rig); // closing without saving puts the saved look back
            this.brake.checked = false;
            setBrakePreview(false);
            (document.activeElement as HTMLElement | null)?.blur?.();
        }
    }

    private switchRig(next: RigId): void {
        setLightSettings(this.saved, false, this.rig);   // leave the old car as it was saved
        this.rig = next;
        this.saved = getLightSettings(next);
        this.draft = { ...this.saved };
        this.syncUI();
        if (this.live.checked) setLightSettings(this.draft, false, next);
        this.updateStatus();
    }

    private save(): void {
        setLightSettings(this.draft, true, this.rig);
        this.saved = getLightSettings(this.rig);
        this.status.className = "status";
        this.status.textContent = "✓ Saved: applied to this car's lights";
    }

    private isDirty(): boolean { return JSON.stringify(this.draft) !== JSON.stringify(this.saved); }

    private updateStatus(): void {
        if (this.isDirty()) {
            this.status.className = "status dirty";
            this.status.textContent = this.live.checked ? "Previewing: press Save to keep it" : "Unsaved changes: press Save to apply";
        } else {
            this.status.className = "status";
            this.status.textContent = "";
        }
    }

    private onEdit(): void {
        if (this.live.checked) setLightSettings(this.draft, false, this.rig);
        this.updateStatus();
    }

    private syncUI(): void { for (const s of this.syncers) s(); }

    private buildCheck(parent: HTMLElement, text: string): HTMLInputElement {
        const label = document.createElement("label");
        const input = document.createElement("input");
        input.type = "checkbox";
        label.append(input, document.createTextNode(text));
        parent.appendChild(label);
        return input;
    }

    private buildRow(f: Field): HTMLElement {
        const row = document.createElement("div");
        row.className = "row";
        const name = document.createElement("span");
        name.textContent = f.label;
        row.appendChild(name);

        if (f.kind === "toggle") {
            const key = f.key;
            const input = document.createElement("input");
            input.type = "checkbox";
            input.addEventListener("change", () => { this.draft[key] = input.checked; this.onEdit(); });
            row.appendChild(input);
            this.syncers.push(() => { input.checked = this.draft[key]; });
        } else if (f.kind === "color") {
            const key = f.key;
            const input = document.createElement("input");
            input.type = "color";
            input.addEventListener("input", () => { this.draft[key] = input.value; this.onEdit(); });
            row.appendChild(input);
            this.syncers.push(() => { input.value = this.draft[key]; });
        } else {
            const key = f.key;
            const val = document.createElement("span");
            val.className = "val";
            const input = document.createElement("input");
            input.type = "range";
            input.min = String(f.min);
            input.max = String(f.max);
            input.step = String(f.step);
            const decimals = f.step >= 1 ? 0 : f.step >= 0.1 ? 1 : f.step >= 0.01 ? 2 : 3;
            input.addEventListener("input", () => {
                const v = Number(input.value);
                this.draft[key] = v;
                val.textContent = v.toFixed(decimals);
                this.onEdit();
            });
            row.append(val, input);
            this.syncers.push(() => {
                input.value = String(this.draft[key]);
                val.textContent = this.draft[key].toFixed(decimals);
            });
        }
        return row;
    }
}