import RAPIER from "@dimforge/rapier3d-compat";

/**
 * Thin wrapper around a Rapier physics world. Rapier is compiled to WebAssembly,
 * so it must be initialized asynchronously before any world is created.
 *
 * The simulation advances at a FIXED 60 Hz timestep through an accumulator:
 * however fast or slow the display renders, every physics step integrates the
 * same 1/60 s, so handling is deterministic and framerate-independent. Vehicle
 * forces must be applied per-substep (see `step`'s callback), not per-frame.
 */
export class Physics {
  /** Fixed integration step (s). All force application should use this dt. */
  static readonly FIXED_DT = 1 / 60;
  /** Cap on substeps per frame so a long frame (tab switch, GC pause) can't
   *  trigger a spiral of death — time beyond the cap is dropped. */
  private static readonly MAX_SUBSTEPS = 4;

  readonly world: RAPIER.World;
  readonly rapier = RAPIER;
  private accumulator = 0;

  private constructor(world: RAPIER.World) {
    this.world = world;
    this.world.timestep = Physics.FIXED_DT;
  }

  /** World gravity (m/s²). Cars are real-scale (metres, kg); the 1.6 arcade weight
   *  factor makes them feel heavy and planted (short, punchy jumps, firm landings).
   *  Car.ts reads this for ride-height maths and CarSpec suspension is tuned for it,
   *  so change it here only (and retune suspensionStiffness if you do). */
  static readonly ARCADE_WEIGHT = 1.6;
  static readonly GRAVITY = 9.81 * Physics.ARCADE_WEIGHT;

  static async create(gravity = { x: 0, y: -Physics.GRAVITY, z: 0 }): Promise<Physics> {
    await RAPIER.init();
    const world = new RAPIER.World(gravity);
    return new Physics(world);
  }

  /**
   * Advance the simulation by `dt` of real time in fixed 60 Hz substeps.
   * `beforeSubstep` runs immediately before each world step — apply vehicle
   * controls/forces there so they integrate with the fixed dt.
   */
  step(dt: number, beforeSubstep?: (fixedDt: number) => void) {
    this.accumulator = Math.min(this.accumulator + dt, Physics.FIXED_DT * Physics.MAX_SUBSTEPS);
    while (this.accumulator >= Physics.FIXED_DT) {
      beforeSubstep?.(Physics.FIXED_DT);
      this.world.step();
      this.accumulator -= Physics.FIXED_DT;
    }
  }

  /**
   * Interpolation alpha: how far (0..1) between the last completed physics
   * step and the next one the current render frame sits. Use this to lerp
   * visual positions between previous and current physics states so movement
   * appears perfectly smooth regardless of framerate/timestep alignment.
   */
  get alpha(): number {
    return this.accumulator / Physics.FIXED_DT;
  }
}
