import { defineConfig } from "vite";
import { resolve } from "path";
import { existsSync } from "fs";

// Rapier ships a .wasm file; Vite handles it as an asset automatically.
// We exclude it from dep-optimization so the wasm loads correctly in dev.
export default defineConfig({
  // Keep the static build portable between domain roots and Pages subpaths.
  base: "./",
  server: { host: true, port: 5173 },
  optimizeDeps: { exclude: ["@dimforge/rapier3d-compat"] },
  build: {
    target: "es2022",
    rollupOptions: {
      input: {
        main: resolve(__dirname, "index.html"),
        // only add the desert page if the folder actually exists
        ...(existsSync(resolve(__dirname, "desert/index.html"))
          ? { desert: resolve(__dirname, "desert/index.html") }
          : {}),
      },
    },
  },
});